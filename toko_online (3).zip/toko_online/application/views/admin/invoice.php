<div class="container-fluid">
    <h4> Invoice Pemesanan Produk</h4>
    <table class="table table-bordered table-striped table-striped">
        <tr>
            <th>id_invoice</th>
            <th>Nama Pemesanan</th>
            <th>Alamat Pengiriman</th>
            <th>Tanggal Pemesanan</th>
            <th>Batas Pembayaran</th>
            <th>Aksi</th>
        </tr>

        <?php if (!empty($invoice)): ?>
            <?php foreach($invoice as $inv) : ?>
            <tr>
                <td><?php echo $inv->id ?></td>
                <td><?php echo $inv->nama ?></td>
                <td><?php echo $inv->alamat ?></td>
                <td><?php echo $inv->tgl_pesan ?></td>
                <td><?php echo $inv->batas_bayar ?></td>
                <td><?php echo anchor('admin/invoice/detail/'.$inv->id, '<div class="btn btn-sm btn-primary">Detail</div>') ?></td>
            </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="6" class="text-center">Belum ada invoice.</td>
            </tr>
        <?php endif; ?>
    </table>

    <div class="mt-3">
        <?php echo anchor('admin/dashboard', 'Kembali ke Dashboard', array('class' => 'btn btn-sm btn-secondary')); ?>
    </div>
</div>
        