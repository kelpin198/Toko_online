<?php
class kategori extends CI_Controller{
    public function elektronik()
    {
        $data['elektronik'] = $this->model_kategori->data_elektronik()->result();
        $this->load->view('template/header');
        $this->load->view('template/sidebar');
        $this->load->view('elektronik', $data);
        $this->load->view('template/footer');
    }

    public function pakaian_pria()
    {
        $data['pakaian_pria'] = $this->model_kategori->data_Pakaian_Pria()->result();
        $this->load->view('template/header');
        $this->load->view('template/sidebar');
        $this->load->view('pakaian_pria', $data);
        $this->load->view('template/footer');
    }

    public function pakaian_wanita()
    {
        $data['pakaian_wanita'] = $this->model_kategori->data_Pakaian_Wanita()->result();
        $this->load->view('template/header');
        $this->load->view('template/sidebar');
        $this->load->view('pakaian_wanita', $data);
        $this->load->view('template/footer');
    }

    public function pakaian_anak_anak()
    {
        $data['pakaian_anak_anak'] = $this->model_kategori->data_Pakaian_Anak_Anak()->result();
        $this->load->view('template/header');
        $this->load->view('template/sidebar');
        $this->load->view('pakaian_anak_anak', $data);
        $this->load->view('template/footer');
    }

    public function peralatan_olahraga()
    {
        $data['peralatan_olahraga'] = $this->model_kategori->data_Peralatan_Olahraga()->result();
        $this->load->view('template/header');
        $this->load->view('template/sidebar');
        $this->load->view('peralatan_olahraga', $data);
        $this->load->view('template/footer');
    }
}
?>